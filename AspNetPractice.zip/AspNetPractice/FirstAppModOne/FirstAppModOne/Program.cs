﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

//int x = 10;
//int y = 10;
//int z = x + y;
//Console.WriteLine("Sum Velu: " + z.ToString());
//Console.ReadLine();


//int x;
//int y;
//Console.WriteLine("Enter First Number");
//x=Convert.ToInt16(Console.ReadLine());

//Console.WriteLine("Enter Second Number");
//y=Convert.ToInt16(Console.ReadLine());

//int z = x + y;
//Console.WriteLine("Sum Velue is :"+z.ToString());
//Console.ReadLine();


//for (int i = 0; i < 10; i++)
//{

//    Console.WriteLine(i.ToString());

//}
//Console.ReadLine();

int i = 0;
while(i<5)
{
    Console.WriteLine(i.ToString());
    //i = i + 1;
     i++;
}
Console.ReadLine();